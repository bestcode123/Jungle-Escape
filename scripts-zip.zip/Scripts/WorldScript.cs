/*
TODO:
	-> Assign this script to 
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorldScript : MonoBehaviour {
	// Variable Declaration
	public class Start() {}
	public class Update() {}
	private int levelIndexVar = SceneManagement.Scene.buildIndex;
	
	// New and improved LoadLevel script:
	int LoadLevel(int levelIndex, string levelName) {
		if(levelIndex != null) {
			SceneManagement.SceneManager.loadLevelAsync(levelIndex);
			return 0;
		} else if(levelName != null) {
			SceneManagement.SceneManager.loadLevelAsync(LevelIndex);
			return 0;
		} else if(levelIndex && levelName) {
			Debug.Log("Error: 2 Full Arguements!");
			return 2;
		} else {
			Debug.Log("Error: No Arguements Given!");
			return 3;
		}
	}
	
	void OnCollisionEnter(Collision collisionMetaData) {
		if(collisionMetaData.gameObject.tag == 'destroy-block') {
			LoadLevel(levelIndexVar, null);
		} else if(collisionMetaData.gameObject.tag == 'next-level-block') {
			levelIndexVar++;
			LoadLevel(levelIndexVar, null);
		}
	}
}