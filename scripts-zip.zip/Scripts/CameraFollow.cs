using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class CameraFollow : MonoBehaviour {
    double DegToRad(double deg) { return deg * Math.PI/180; }

    // Variables:
    private bool isThirdPerson = true;
    public GameObject character;
    public float camDistance;
    private double turnAmount = 25;
    private double angleY;
    public Vector3 offset;
    // Start is called before the first frame update
    void Start() {
        angleY += 90;
    }

    // Update is called once per frame
    void Update() {
        if(isThirdPerson) {
            if(Input.GetKey(KeyCode.L)) {
                angleY += Convert.ToSingle(turnAmount) * Time.deltaTime;
            } else if(Input.GetKey(KeyCode.J)) {
                angleY -= Convert.ToSingle(turnAmount) * Time.deltaTime;
            }
            this.transform.position = character.transform.position + new Vector3(-camDistance * Convert.ToSingle(Math.Sin(DegToRad(angleY))), 4, -camDistance * Convert.ToSingle(Math.Cos(DegToRad(angleY))));
            this.transform.eulerAngles = new Vector3(0, Convert.ToSingle(angleY), 0);
            if(Input.GetKeyDown(KeyCode.E)) {
                isThirdPerson = false;
            }
        } else {
            if(Input.GetKey(KeyCode.L)) {
                angleY += Convert.ToSingle(turnAmount) * Time.deltaTime;
            } else if(Input.GetKey(KeyCode.J)) {
                angleY -= Convert.ToSingle(turnAmount) * Time.deltaTime;
            }
            this.transform.position = character.transform.position + offset;
            this.transform.eulerAngles = new Vector3(0, Convert.ToSingle(angleY), 0);
            if(Input.GetKeyDown(KeyCode.E)) {
                isThirdPerson = true;
            }
        }
    }
}
