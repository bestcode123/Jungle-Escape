/*
This file controls the player and hat movement.

TODO:
	-> Implement the level design
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class PlayerMovement : MonoBehaviour {
    double DegToRad(double deg) { return deg * Math.PI/180; }
    // Variables:
    private double angleY;
    public double angleYStart;
    public double moveAmount;
    private double turnAmount = 25;
    public Rigidbody rb;
    public float jumpForce;
	public GameObject character;
	public Vector3 hatOffset;
	public GameObject hat;
	public float upForce;
    // Start is called before the first frame update
    void Start() {
        angleY += angleYStart;
    }

    // Update is called once per frame
    void FixedUpdate() {
		// Rotation:
        if(Input.GetKey(KeyCode.L)) {
            this.transform.eulerAngles += new Vector3(0, Convert.ToSingle(turnAmount), 0) * Time.deltaTime;
            angleY += Convert.ToSingle(turnAmount) * Time.deltaTime;
        } else if(Input.GetKey(KeyCode.J)) {
            this.transform.eulerAngles -= new Vector3(0, Convert.ToSingle(turnAmount), 0) * Time.deltaTime;
            angleY -= Convert.ToSingle(turnAmount) * Time.deltaTime;
        }
		// The new and improved movement system:
        if(Input.GetKey(KeyCode.A)) {
            this.transform.position += new Vector3(Convert.ToSingle(moveAmount * Math.Sin(DegToRad(angleY))), 0, Convert.ToSingle(moveAmount * Math.Cos(DegToRad(angleY)))) * Time.deltaTime;
        } if(Input.GetKey(KeyCode.D)) {
            this.transform.position -= new Vector3(Convert.ToSingle(moveAmount * Math.Sin(DegToRad(angleY))), 0, Convert.ToSingle(moveAmount * Math.Cos(DegToRad(angleY)))) * Time.deltaTime;
        } if(Input.GetKey(KeyCode.S)) {
            this.transform.position -= new Vector3(Convert.ToSingle(moveAmount * Math.Sin(DegToRad(angleY + 90))), 0, Convert.ToSingle(moveAmount * Math.Cos(DegToRad(angleY + 90)))) * Time.deltaTime;
        } if(Input.GetKey(KeyCode.W)) {
            this.transform.position += new Vector3(Convert.ToSingle(moveAmount * Math.Sin(DegToRad(angleY + 90))), 0, Convert.ToSingle(moveAmount * Math.Cos(DegToRad(angleY + 90)))) * Time.deltaTime;
        } if(Input.GetKeyDown(KeyCode.Space)) {
            if(Input.GetKeyDown(KeyCode.Space)) {
                rb.AddForce(new Vector3(0, upForce, 0) * Time.deltaTime);
            }
        }
		hat.transform.postion = character.transform.position + hatOffset;
    }
}
